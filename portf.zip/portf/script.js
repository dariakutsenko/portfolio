
const canvas = document.getElementById('pixelCanvas');
const ctx = canvas.getContext('2d');

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

const pixels = [];
const PIXEL_SIZE = 4;

function initPixels() {
    const cols = Math.ceil(canvas.width / PIXEL_SIZE);
    const rows = Math.ceil(canvas.height / PIXEL_SIZE);
    for (let i = 0; i < 150; i++) {
        pixels.push({
            x: Math.floor(Math.random() * cols) * PIXEL_SIZE,
            y: Math.floor(Math.random() * rows) * PIXEL_SIZE,
            size: PIXEL_SIZE,
            speed: 0.1 + Math.random() * 0.3,
            alpha: 0.1 + Math.random() * 0.3,
            color: `hsl(${280 + Math.random() * 60}, 80%, 60%)`
        });
    }
}
initPixels();

function drawPixels() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    pixels.forEach(p => {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fillRect(p.x, p.y, p.size, p.size);
        p.y -= p.speed;
        if (p.y < 0) {
            p.y = canvas.height;
            p.x = Math.floor(Math.random() * (canvas.width / PIXEL_SIZE)) * PIXEL_SIZE;
        }
    });
    ctx.globalAlpha = 1;
    requestAnimationFrame(drawPixels);
}
drawPixels();

let hp = 0;
let secondsOnSite = 0;
const maxHP = 100;
const healthFill = document.getElementById('healthFill');
const healthText = document.getElementById('healthText');

setInterval(() => {
    secondsOnSite++;
    hp = Math.min(maxHP, Math.round(0 + secondsOnSite / 2));
    healthFill.style.width = hp + '%';
    healthText.textContent = hp + '/100';
}, 1000);

const menuBtns = document.querySelectorAll('.menu-btn');
const screens = {
    home: document.getElementById('section-home'),
    games: document.getElementById('section-games'),
    web: document.getElementById('section-web'),
    about: document.getElementById('section-about'),
    contact: document.getElementById('section-contact')
};

menuBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        menuBtns.forEach(b => b.classList.remove('active'));
        this.classList.add('active');

        Object.values(screens).forEach(s => s.classList.remove('active'));

        const section = this.dataset.section;
        if (screens[section]) {
            screens[section].classList.add('active');
        }
    });
});

const gamesData = [
    {
        title: 'Forest Cat',
        badge: 'Проект',
        desc: 'Разработка игры с помощью Pygame. Игра представляет собой пиксельную аркаду с линейным прохождением локаций. Главный герой игры кошка, которая, преодолевая различные препятствия, должна добраться до финальной точки - домика.',
        img: './images/game.png'
    },
    {
        title: 'Мудборд',
        badge: 'Атмосфера',
        desc: 'Подборка референсов, цветовых палитр и ассоциаций для пиксельной аркады "Forest Cat". При создании вдохновлялась старыми пиксель-арт играми.',
        img: './images/m.png'
    },
    {
        title: 'Отрисовка',
        badge: 'UI/UX',
        desc: 'Отрисовка главного героя, NPC и игровых предметов. Использовала Figma как основной инструмент.',
        img: './images/pip.png'
    }
];

const webData = [
    {
        title: 'Samorazbor',
        badge: 'Многостраничный сайт',
        desc: 'Создание сайта с психологическими тестами и статьями.',
        img: './images/saittt.png'
    },
    {
        title: 'DesignPlay',
        badge: 'Макет',desc: 'Создание макета будущего сайта с интерактивными приложениями с помощью Figma.',
        img: './images/sait.png'
    },
    {
        title: 'Контент-платформа',
        badge: 'Дизайн-система',
        desc: 'Разработка интерактивной дизайн-системы сайта любителей аниме "Клинок, рассекающий демонов".',
        img: './images/klinok.png'
    },
    {
        title: 'Форма регистрации',
        badge: 'UI/UX',
        desc: 'Разработка адаптивной регистрации для веб-сайта.',
        img: './images/forma.jpg'
    },
    {
        title: 'Логотип',
        badge: 'UI/UX',
        desc: 'Создание логотипа для веб-сайта с аниме контентом.',
        img: './images/logo.png'
    },
    {
        title: 'Отчисления студентов',
        badge: 'Инфографика',
        desc: 'Визуализация данных об основных причиинах отчисления студентов.s',
        img: './images/info.png'
    },
];
function renderCards(data, containerId, cardClass = '') {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = data.map(item => `
        <div class="pixel-card ${cardClass}">
            <img src="${item.img}" alt="${item.title}">
            <span class="card-badge">${item.badge}</span>
            <h3>${item.title}</h3>
            <p>${item.desc}</p>
            <a href="#" class="card-link">▶ Смотреть</a>
        </div>
    `).join('');
}

renderCards(gamesData, 'gamesGrid');
renderCards(webData, 'webGrid', 'web-card'); // 👈 ВЕБ-КАРТОЧКИ С КЛАССОМ


document.getElementById('startBtn').addEventListener('click', function() {
    const gamesBtn = document.querySelector('[data-section="games"]');
    if (gamesBtn) gamesBtn.click();

    document.querySelector('.game-container').style.animation = 'pixelFade 0.1s steps(3)';
    setTimeout(() => {
        document.querySelector('.game-container').style.animation = '';
    }, 200);
});


const modalOverlay = document.getElementById('modalOverlay');
const modalClose = document.getElementById('modalClose');
const modalImage = document.getElementById('modalImage');
const modalTitle = document.getElementById('modalTitle');

function openModal(card) {
    const img = card.querySelector('img');
    const title = card.querySelector('h3')?.textContent || 'Без названия';

    modalImage.src = img.src;
    modalImage.alt = img.alt || 'Работа';
    modalTitle.textContent = title;

    modalOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
}

document.addEventListener('click', function(e) {
    const card = e.target.closest('.pixel-card');
    if (card) {
        openModal(card);
    }
});

modalClose.addEventListener('click', closeModal);

modalOverlay.addEventListener('click', function(e) {
    if (e.target === modalOverlay) {
        closeModal();
    }
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
    }
});

